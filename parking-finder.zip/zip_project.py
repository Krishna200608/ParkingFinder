import os
import zipfile

ZIP_NAME = "parking-finder.zip"

EXCLUDE_DIRS = {
    "node_modules",
    "dist",
    "build",
    ".git",
    ".vscode",
    ".idea",
    "__pycache__",
}

EXCLUDE_FILES = {
    ".env",              # <--- Do NOT zip real .env
    ".env.local",
    ".DS_Store",
    "Thumbs.db"
}

def should_exclude(path):
    parts = path.split(os.sep)
    return any(part in EXCLUDE_DIRS for part in parts) or any(path.endswith(f) for f in EXCLUDE_FILES)

def zip_project(root_folder):
    with zipfile.ZipFile(ZIP_NAME, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(root_folder):

            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]

            for file in files:
                filepath = os.path.join(root, file)
                relative_path = os.path.relpath(filepath, root_folder)

                # Skip real .env but allow .env.example
                if should_exclude(relative_path):
                    continue

                zipf.write(filepath, relative_path)

    print(f"\n✅ Project zipped successfully → {ZIP_NAME}\n")

if __name__ == "__main__":
    zip_project(os.getcwd())
